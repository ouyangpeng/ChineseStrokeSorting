package com.jf.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.junfeng.strokesort.comparator.StringStrokeComparator;

public class TestStringStrokeComparator {

	public static void main(String[] args) {
		List<String> name = new ArrayList<String>();
		name.add("张三仨");
		name.add("张三是");
		name.add("张三");
		name.add("赵明");
		name.add("李四");
		name.add("王东西");

		/** 使用 */
		Collections.sort(name, new StringStrokeComparator());

		for (String string : name) {
			System.out.println(string);
		}
	}
}
